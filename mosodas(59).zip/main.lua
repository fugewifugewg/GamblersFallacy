SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {27,19,14,9,18,17,6,28,4,13,29,7,5,8,20,11,12,24,30,15,3,23,2,25,26,1,16,21,22,10}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end


local sealIndexList = {1}

local function load_seals_folder()
    local mod_path = SMODS.current_mod.path
    local seals_path = mod_path .. "/seals"
    local files = NFS.getDirectoryItemsInfo(seals_path)
    for i = 1, #sealIndexList do
        local file_name = files[sealIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("seals/" .. file_name))()
        end
    end
end


local function load_boosters_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("boosters.lua"))()
end

load_boosters_file()
load_jokers_folder()
load_seals_folder()
SMODS.ObjectType({
    key = "mosodas_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "mosodas_soda_jokers",
    cards = {
        ["j_mosodas__1free"] = true,
        ["j_mosodas__5hboost"] = true,
        ["j_mosodas_bigsoda"] = true,
        ["j_mosodas_bossrefreshment"] = true,
        ["j_mosodas_bubblingbuffoon"] = true,
        ["j_mosodas_colastock"] = true,
        ["j_mosodas_cosmicbrew"] = true,
        ["j_mosodas_crystalcola"] = true,
        ["j_mosodas_deluxecola"] = true,
        ["j_mosodas_emptybottle"] = true,
        ["j_mosodas_faygo"] = true,
        ["j_mosodas_freespin"] = true,
        ["j_mosodas_genericcola"] = true,
        ["j_mosodas_grapetonic"] = true,
        ["j_mosodas_liquidgold"] = true,
        ["j_mosodas_perkeoschoice"] = true,
        ["j_mosodas_pride"] = true,
        ["j_mosodas_promotionalpunch"] = true,
        ["j_mosodas_raspberryrush"] = true,
        ["j_mosodas_scancodeforfreeprize"] = true,
        ["j_mosodas_sixpack"] = true,
        ["j_mosodas_sodamaker"] = true,
        ["j_mosodas_soulda"] = true,
        ["j_mosodas_sparklingwater"] = true,
        ["j_mosodas_unlabeledbeverage"] = true,
        ["j_mosodas_unsupervisedsodadispencer"] = true,
        ["j_mosodas_urgent"] = true,
        ["j_mosodas_vup"] = true,
        ["j_mosodas_witchesbrew"] = true,
        ["j_mosodas_xenosurprise"] = true
    },
})