SMODS.Seal {
    key = 'colasyrup',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            x_mult = 0,
            x_chips = 0
        }
    },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Cola Syrup',
        label = 'Cola Syrup',
        text = {
        [1] = '{X:inactive,C:white}X0{} {C:red}Mult{} {X:inactive,C:white}X0{} {C:blue}Chips{}',
        [2] = 'When scored destroy card and create a {C:attention}Soda{}',
        [3] = '{C:inactive}(must have room){}'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            G.E_MANAGER:add_event(Event({
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Destroyed!", colour = G.C.RED})
            return
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            card.should_destroy = true
            local created_joker = false
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    created_joker = true
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'mosodas_soda_jokers' })
                        if joker_card then
                            
                            
                        end
                        G.GAME.joker_buffer = 0
                        return true
                    end
                }))
                end
            SMODS.calculate_effect({x_mult = card.ability.seal.extra.x_mult}, card)
            SMODS.calculate_effect({x_chips = card.ability.seal.extra.x_chips}, card)
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
        end
    end
}