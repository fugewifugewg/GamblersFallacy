SMODS.Booster {
    key = 'sodapack',
    loc_txt = {
        name = "Soda Pack",
        text = {
            "Choose 1 of up to 3 Sodas"
        },
        group_name = "Soda Pack"
    },
    config = { extra = 3, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            5,
            0.3
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('mosodas_sodapack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            set = "mosodas_soda_jokers",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "mosodas_sodapack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_diet_cola",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "mosodas_sodapack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
