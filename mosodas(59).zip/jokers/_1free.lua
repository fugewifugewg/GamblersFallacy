SMODS.Joker{ --+1 Free!
    key = "_1free",
    config = {
        extra = {
            activations = 0
        }
    },
    loc_txt = {
        ['name'] = '+1 Free!',
        ['text'] = {
            [1] = 'Stores a {C:attention}Double Tag{} every time a {C:attention}Tag{} is added',
            [2] = 'Sell this card to create {C:attention}#1#{} free {C:attention}Double Tags{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["mosodas_soda_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_TAGS["tag_double"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"tag_double\" isn't a valid Tag key, Did you misspell it or forgot a modprefix?")
        end
        return {vars = {card.ability.extra.activations}}
    end,

    calculate = function(self, card, context)
        if context.tag_added  then
                return {
                    func = function()
                    card.ability.extra.activations = (card.ability.extra.activations) + 1
                    return true
                end,
                    extra = {
                        message = "+1",
                        colour = G.C.ORANGE
                        }
                }
        end
        if context.selling_self  then
            if true then
                for i = 1, card.ability.extra.activations do
              SMODS.calculate_effect({func = function()
            G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_double")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
                    return true
                end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Created Tag!", colour = G.C.GREEN})
                        SMODS.calculate_effect({func = function()
                    card.ability.extra.activations = math.max(0, (card.ability.extra.activations) - 1)
                    return true
                end}, card)
          end
            end
        end
    end
}