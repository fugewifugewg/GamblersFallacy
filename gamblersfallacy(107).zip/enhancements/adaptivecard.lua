SMODS.Enhancement {
    key = 'adaptivecard',
    pos = { x = 0, y = 0 },
    loc_txt = {
        name = 'Adaptive Card',
        text = {
        [1] = '{C:green}Reroll{} suit and rank when discarded',
        [2] = 'Remove {C:enhanced}Enhancement{} when scored'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.discard and context.other_card == card then
            return { func = function()
                assert(SMODS.change_base(context.other_card, pseudorandom_element(SMODS.Suits, 'edit_card_suit').key, pseudorandom_element(SMODS.Ranks, 'edit_card_rank').key))
                    end }
        end
        if context.main_scoring and context.cardarea == G.play then
            card:set_ability(G.P_CENTERS.c_base)
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
        end
    end
}