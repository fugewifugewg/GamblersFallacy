SMODS.Joker{ --Merchant
    key = "merchant",
    config = {
        extra = {
            OwnSellValue = 0,
            start_dissolve = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Merchant',
        ['text'] = {
            [1] = '{C:attention}+1 Booster Pack{} and {C:attention}+1 Voucher{} slot',
            [2] = '{C:red}self destructs{} when booster pack is opened'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["gamblers_gamblers_jokers"] = true },

    calculate = function(self, card, context)
        if context.open_booster  then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        SMODS.change_booster_limit(1)
        SMODS.change_voucher_limit(1)
    end,

    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_booster_limit(-1)
        SMODS.change_voucher_limit(-1)
    end
}