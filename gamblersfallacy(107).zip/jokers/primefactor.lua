SMODS.Joker{ --Prime Factor
    key = "primefactor",
    config = {
        extra = {
            source_rank_type = "specific",
            source_ranks = {"4", "8"},
            target_rank = "2",
            source_rank_type = "specific",
            source_ranks = {"6", "9"},
            target_rank = "3",
            source_rank_type = "specific",
            source_ranks = {"10"},
            target_rank = "5",
            overkill = 0
        }
    },
    loc_txt = {
        ['name'] = 'Prime Factor',
        ['text'] = {
            [1] = 'Cards ranks {C:red}only{} count as their {C:attention}biggest{} prime factor',
            [2] = 'ex: {C:attention}10{} count as {C:attention}5{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["gamblers_gamblers_jokers"] = true },

    calculate = function(self, card, context)
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
    end
}


local card_get_id_ref = Card.get_id
function Card:get_id()
    local original_id = card_get_id_ref(self)
    if not original_id then return original_id end

    if next(SMODS.find_card("j_gamblers_primefactor")) then
        local source_ids = {4, 8}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 2 end
        end
    end
    if next(SMODS.find_card("j_gamblers_primefactor")) then
        local source_ids = {6, 9}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 3 end
        end
    end
    if next(SMODS.find_card("j_gamblers_primefactor")) then
        local source_ids = {10}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 5 end
        end
    end
    return original_id
end
