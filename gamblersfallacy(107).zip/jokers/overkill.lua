SMODS.Joker{ --Overkill
    key = "overkill",
    config = {
        extra = {
            BlindMultiplier = 1,
            blind_size = 2
        }
    },
    loc_txt = {
        ['name'] = 'Overkill',
        ['text'] = {
            [1] = '{C:red}Blind multiplier X2{} every first hand',
            [2] = '{C:blue}Blind multiplier ÷2{} every other hand',
            [3] = 'Earn {C:money}$ = Blind multiplier{} at end of round',
            [4] = '{C:inactive}(Currently{} {C:red}X#1#{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["gamblers_gamblers_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.BlindMultiplier}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (not (G.GAME.current_round.hands_played == 0) and (card.ability.extra.BlindMultiplier or 0) >= 2) then
                card.ability.extra.BlindMultiplier = (card.ability.extra.BlindMultiplier) / 2
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Halve", colour = G.C.GREEN})
                G.GAME.blind.chips = G.GAME.blind.chips / card.ability.extra.blind_size
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                G.HUD_blind:recalculate()
                return true
            end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                local BlindMultiplier_value = card.ability.extra.BlindMultiplier
                return {
                    dollars = BlindMultiplier_value,
                    extra = {
                        func = function()
                    card.ability.extra.BlindMultiplier = (card.ability.extra.BlindMultiplier) * 2
                    return true
                end,
                            message = "Double",
                        colour = G.C.MULT
                        }
                }
        end
        if context.setting_blind  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = " ", colour = G.C.GREEN})
                G.GAME.blind.chips = G.GAME.blind.chips * card.ability.extra.BlindMultiplier
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                G.HUD_blind:recalculate()
                return true
            end
                }
        end
    end
}