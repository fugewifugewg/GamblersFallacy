SMODS.Joker{ --Plasma: The Joker
    key = "plasmathejoker",
    config = {
        extra = {
            blind_size = 2
        }
    },
    loc_txt = {
        ['name'] = 'Plasma: The Joker',
        ['text'] = {
            [1] = 'Balance {C:blue}Chips{} and {C:red}Mult{}',
            [2] = 'when calculating score for played hand',
            [3] = '{C:red}X2{} base Blind size'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["gamblers_gamblers_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
                return {
                    balance = true
                }
        end
        if context.setting_blind  and not context.blueprint then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(card.ability.extra.blind_size).." Blind Size", colour = G.C.GREEN})
                G.GAME.blind.chips = G.GAME.blind.chips * card.ability.extra.blind_size
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                G.HUD_blind:recalculate()
                return true
            end
                }
        end
    end
}