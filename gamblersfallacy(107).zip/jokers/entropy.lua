SMODS.Joker{ --Entropy
    key = "entropy",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Entropy',
        ['text'] = {
            [1] = 'If played hand has {C:orange}5{} scoring cards',
            [2] = 'randomize their rank and suit'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if #context.scoring_hand == 5 then
                assert(SMODS.change_base(context.other_card, pseudorandom_element(SMODS.Suits, 'edit_card_suit').key, pseudorandom_element(SMODS.Ranks, 'edit_card_rank').key))
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}