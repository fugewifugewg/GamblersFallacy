SMODS.Joker{ --Investor
    key = "investor",
    config = {
        extra = {
            var1 = 0,
            otherjokerssellvalue = 0
        }
    },
    loc_txt = {
        ['name'] = 'Investor',
        ['text'] = {
            [1] = 'Earn half the sell value of all other owned {C:attention}Jokers{} in {C:money}${} at end of round'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
                return {
                    dollars = ((function() local total = 0; for _, joker in ipairs(G.jokers and G.jokers.cards or {}) do if joker ~= card then total = total + joker.sell_cost end end; return total end)()) * 0.5
                }
        end
    end
}