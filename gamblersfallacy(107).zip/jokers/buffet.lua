SMODS.Joker{ --Buffet
    key = "buffet",
    config = {
        extra = {
            multvar = 20,
            currenthandplayedcount = 0,
            mult = 20
        }
    },
    loc_txt = {
        ['name'] = 'Buffet',
        ['text'] = {
            [1] = '{C:mult}+20{} Mult if {C:attention}poker hand{} has been played {C:attention}5{} times or less'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["gamblers_food_joker"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.hands[context.scoring_name].played <= 5 then
                return {
                    mult = card.ability.extra.mult
                }
            elseif G.GAME.hands[context.scoring_name].played > 5 then
                return {
                    message = "empty"
                }
            end
        end
    end
}