SMODS.Joker{ --Echo
    key = "echo",
    config = {
        extra = {
            echo = 1
        }
    },
    loc_txt = {
        ['name'] = 'Echo',
        ['text'] = {
            [1] = 'Retrigger played cards for every time',
            [2] = 'the {C:attention}poker hand{} has been played this round'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if G.GAME.hands[context.scoring_name] and G.GAME.hands[context.scoring_name].played_this_round > 1 then
                card.ability.extra.echo = (card.ability.extra.echo) + 1
            end
        end
        if context.repetition and context.cardarea == G.play  then
            if G.GAME.hands[context.scoring_name] and G.GAME.hands[context.scoring_name].played_this_round > 1 then
                return {
                    repetitions = card.ability.extra.echo,
                    message = "echo"
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.echo = 1
                    return true
                end,
                    message = "reset"
                }
        end
    end
}