SMODS.Joker{ --Gamblers Particle Accelerator
    key = "zgamblersparticleaccelerator",
    config = {
        extra = {
            ChaosEngineProbabilityBonus = 0,
            example1 = 1,
            example2 = 3,
            numerator = 0,
            denominator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Gamblers Particle Accelerator',
        ['text'] = {
            [1] = 'Increments {C:green}both sides{} of all {C:attention}listed{} {C:green}probabilities{} by {C:green}1{}',
            [2] = 'for every {C:attention}consecutive{} {C:green}successful{} roll',
            [3] = '(Current ex: {C:green}1 in 3{} -> {C:green}#2# in #3#{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.ChaosEngineProbabilityBonus, card.ability.extra.example1, card.ability.extra.example2}}
    end,

    calculate = function(self, card, context)
        if context.pseudorandom_result  and not context.blueprint then
            if context.result then
                return {
                    func = function()
                    card.ability.extra.ChaosEngineProbabilityBonus = (card.ability.extra.ChaosEngineProbabilityBonus) + 1
                    return true
                end,
                    message = "+1 in +1",
                    extra = {
                        func = function()
                    card.ability.extra.example1 = (card.ability.extra.example1) + 1
                    return true
                end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                    card.ability.extra.example2 = (card.ability.extra.example2) + 1
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                }
            elseif (not context.result and (card.ability.extra.ChaosEngineProbabilityBonus or 0) ~= 0) then
                return {
                    func = function()
                    card.ability.extra.ChaosEngineProbabilityBonus = 0
                    return true
                end,
                    message = "Reset!",
                    extra = {
                        func = function()
                    card.ability.extra.example1 = 1
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.example2 = 3
                    return true
                end,
                            colour = G.C.BLUE
                        }
                        }
                }
            end
        end
          if context.mod_probability and not context.blueprint then
          local numerator, denominator = context.numerator, context.denominator
                  numerator = numerator + card.ability.extra.ChaosEngineProbabilityBonus
                denominator = denominator + card.ability.extra.ChaosEngineProbabilityBonus
        return {
          numerator = numerator, 
          denominator = denominator
        }
          end
    end
}