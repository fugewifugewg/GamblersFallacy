SMODS.Joker{ --Crescendo
    key = "crescendo",
    config = {
        extra = {
            xmultvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Crescendo',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.5{} Mult for every {C:blue}hand{} played this round',
            [2] = '{C:inactive}(Currently {C:red}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmultvar}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                local xmultvar_value = card.ability.extra.xmultvar
                card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 0.5
                return {
                    Xmult = xmultvar_value
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.xmultvar = 1
                    return true
                end
                }
        end
    end
}