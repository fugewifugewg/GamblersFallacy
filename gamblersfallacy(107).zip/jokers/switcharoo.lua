SMODS.Joker{ --Switcharoo
    key = "switcharoo",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Switcharoo',
        ['text'] = {
            [1] = 'Swap {C:blue}Chips{} and {C:red}Mult{} when activated'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["gamblers_gamblers_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    swap = true,
                    message = "Swap"
                }
        end
    end
}