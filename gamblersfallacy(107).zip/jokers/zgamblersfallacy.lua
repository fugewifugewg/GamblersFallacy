SMODS.Joker{ --Gamblers Fallacy
    key = "zgamblersfallacy",
    config = {
        extra = {
            ChaosEngineProbabilityBonus = 0,
            Example1 = 1,
            var1 = 0,
            numerator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Gamblers Fallacy',
        ['text'] = {
            [1] = 'Increments all {C:attention}listed{} {C:green}probabilities{} by {C:green}1{}',
            [2] = 'for every {C:attention}consecutive{} {C:red}failed{} roll',
            [3] = '(Current ex: {C:green}1 in 3{} -> {C:green}#2# in 3{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.ChaosEngineProbabilityBonus, card.ability.extra.Example1}}
    end,

    calculate = function(self, card, context)
        if context.pseudorandom_result  and not context.blueprint then
            if not context.result then
                return {
                    func = function()
                    card.ability.extra.ChaosEngineProbabilityBonus = (card.ability.extra.ChaosEngineProbabilityBonus) + 1
                    return true
                end,
                    message = "+1",
                    extra = {
                        func = function()
                    card.ability.extra.Example1 = (card.ability.extra.Example1) + 1
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            elseif (context.result and (card.ability.extra.var1 or 0) ~= 0) then
                return {
                    func = function()
                    card.ability.extra.ChaosEngineProbabilityBonus = 0
                    return true
                end,
                    message = "Reset!",
                    extra = {
                        func = function()
                    card.ability.extra.Example1 = 1
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            end
        end
          if context.mod_probability and not context.blueprint then
          local numerator, denominator = context.numerator, context.denominator
                  numerator = numerator + card.ability.extra.ChaosEngineProbabilityBonus
        return {
          numerator = numerator, 
          denominator = denominator
        }
          end
    end
}