SMODS.Joker{ --Clown Car
    key = "clowncar",
    config = {
        extra = {
            ClownCar = 0,
            start_dissolve = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Clown Car',
        ['text'] = {
            [1] = '{C:dark_edition,E:1}+99{} {C:inactive}Joker slots{}',
            [2] = '{C:red}self destructs{} on shop exit'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["gamblers_gamblers_jokers"] = true },

    calculate = function(self, card, context)
        if context.ending_shop  and not context.blueprint then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.jokers.config.card_limit = G.jokers.config.card_limit + 99
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.jokers.config.card_limit = G.jokers.config.card_limit - 99
    end
}